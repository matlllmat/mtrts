<!-- Back + breadcrumb row -->
<div class="flex items-center gap-2 mb-4">
  <a href="index.php"
     class="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900 transition-colors">
    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
    </svg>
    Back to Work Orders
  </a>
  <span class="text-gray-300">/</span>
  <span class="text-sm font-semibold text-gray-700"><?= htmlspecialchars($wo['wo_number']) ?></span>
</div>

<?php if ($is_overdue): ?>
<div class="wo-banner banner-warn mb-4">
  <svg class="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
  </svg>
  <span>This work order is <strong>overdue</strong> — scheduled end was <?= (new DateTime($wo['scheduled_end']))->format('M j, Y g:ia') ?>.</span>
</div>
<?php endif; ?>

<?php if ($wo['status'] === 'on_hold' && $wo['on_hold_reason']): ?>
<div class="wo-banner banner-info mb-4">
  <svg class="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path stroke-linecap="round" stroke-linejoin="round" d="M14.25 9v6m-4.5 0V9M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
  </svg>
  <span>Work order is <strong>on hold</strong> — <?= wo_hold_reason($wo['on_hold_reason']) ?></span>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 xl:grid-cols-[1fr_260px] gap-4 items-start">

  <!-- LEFT COLUMN -->
  <div class="flex flex-col gap-4">

    <!-- WO info card -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="px-6 py-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-gray-900 flex items-center gap-2">
            <span class="block w-0.5 h-4 bg-olfu-green rounded"></span>
            Work Order Information
          </h2>
          <p class="text-xs text-gray-400 mt-0.5">
            Viewing <?= htmlspecialchars($wo['wo_number']) ?> — <?= wo_type_badge($wo['wo_type']) ?>
          </p>
        </div>
        <div class="flex gap-2 flex-wrap">
          <a href="edit.php?id=<?= $id ?>"
             class="inline-flex items-center gap-1.5 bg-amber-50 border border-amber-300 text-amber-700 hover:bg-amber-100 text-sm font-semibold px-3 py-1.5 rounded-lg transition-colors">
            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            Edit
          </a>
        </div>
      </div>

      <div class="p-6">
        <div class="grid grid-cols-2 md:grid-cols-3 gap-5">
          <div>
            <div class="vf-lbl">WO Number</div>
            <div class="vf-val vf-mono"><?= htmlspecialchars($wo['wo_number']) ?></div>
          </div>
          <div>
            <div class="vf-lbl">Type</div>
            <div class="vf-val"><?= wo_type_badge($wo['wo_type']) ?></div>
          </div>
          <div>
            <div class="vf-lbl">Status</div>
            <div class="vf-val"><?= wo_status_badge($wo['status']) ?></div>
          </div>
          <div>
            <div class="vf-lbl">Linked Ticket</div>
            <?php if ($wo['ticket_number']): ?>
              <div class="vf-val vf-mono"><?= htmlspecialchars($wo['ticket_number']) ?></div>
            <?php else: ?>
              <div class="text-red-400 text-xs font-bold italic">Unlinked — Ticket Required</div>
            <?php endif; ?>
          </div>
          <div>
            <div class="vf-lbl">Priority</div>
            <div class="vf-val"><?= wo_priority_badge($wo['priority'] ?? null) ?></div>
          </div>
          <div>
            <div class="vf-lbl">RMA</div>
            <div class="vf-val"><?= $wo['is_rma'] ? '<span class="wo-badge badge-type-diagnosis">Yes — RMA</span>' : '<span class="text-gray-400">No</span>' ?></div>
          </div>

          <!-- Asset info -->
          <?php if ($wo['asset_tag']): ?>
          <div class="col-span-2 md:col-span-3">
            <div class="sdiv">Linked Asset</div>
            <div class="grid grid-cols-3 gap-4">
              <div>
                <div class="vf-lbl">Asset Tag</div>
                <div class="vf-val vf-mono"><?= htmlspecialchars($wo['asset_tag']) ?></div>
              </div>
              <div>
                <div class="vf-lbl">Model</div>
                <div class="vf-val"><?= htmlspecialchars(($wo['manufacturer'] ?? '') . ' ' . ($wo['model'] ?? '')) ?></div>
              </div>
              <div>
                <div class="vf-lbl">Category</div>
                <div class="vf-val"><?= htmlspecialchars($wo['category_name'] ?? '—') ?></div>
              </div>
            </div>
          </div>
          <?php endif; ?>

          <!-- Location -->
          <?php if ($wo['building']): ?>
          <div class="col-span-2 md:col-span-3">
            <div class="sdiv">Location</div>
            <div class="grid grid-cols-3 gap-4">
              <div>
                <div class="vf-lbl">Building</div>
                <div class="vf-val"><?= htmlspecialchars($wo['building']) ?></div>
              </div>
              <div>
                <div class="vf-lbl">Floor</div>
                <div class="vf-val"><?= htmlspecialchars($wo['floor']) ?></div>
              </div>
              <div>
                <div class="vf-lbl">Room</div>
                <div class="vf-val"><?= htmlspecialchars($wo['room']) ?></div>
              </div>
            </div>
          </div>
          <?php endif; ?>

          <!-- Assignment -->
          <div class="col-span-2 md:col-span-3">
            <div class="sdiv">Assignment</div>
            <div class="grid grid-cols-2 gap-4">
              <div>
                <div class="vf-lbl">Assigned To</div>
                <?php if ($wo['technician_name']): ?>
                  <div class="vf-val"><?= htmlspecialchars($wo['technician_name']) ?></div>
                <?php else: ?>
                  <div class="vf-empty">Unassigned</div>
                <?php endif; ?>
              </div>
              <div>
                <div class="vf-lbl">Assigned By</div>
                <div class="vf-val"><?= $wo['assigned_by_name'] ? htmlspecialchars($wo['assigned_by_name']) : '<span class="vf-empty">—</span>' ?></div>
              </div>
            </div>
          </div>

          <!-- Schedule -->
          <div class="col-span-2 md:col-span-3">
            <div class="sdiv">Schedule</div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div class="vf-lbl">Scheduled Start</div>
                <div class="vf-val"><?= $wo['scheduled_start'] ? (new DateTime($wo['scheduled_start']))->format('M j, Y g:ia') : '<span class="vf-empty">Not set</span>' ?></div>
              </div>
              <div>
                <div class="vf-lbl">Scheduled End</div>
                <div class="vf-val <?= $is_overdue ? 'text-red-600' : '' ?>"><?= $wo['scheduled_end'] ? (new DateTime($wo['scheduled_end']))->format('M j, Y g:ia') : '<span class="vf-empty">Not set</span>' ?></div>
              </div>
              <div>
                <div class="vf-lbl">Actual Start</div>
                <div class="vf-val"><?= $wo['actual_start'] ? (new DateTime($wo['actual_start']))->format('M j, Y g:ia') : '<span class="vf-empty">—</span>' ?></div>
              </div>
              <div>
                <div class="vf-lbl">Actual End</div>
                <div class="vf-val"><?= $wo['actual_end'] ? (new DateTime($wo['actual_end']))->format('M j, Y g:ia') : '<span class="vf-empty">—</span>' ?></div>
              </div>
            </div>
          </div>

          <!-- Notes -->
          <?php if ($wo['notes']): ?>
          <div class="col-span-2 md:col-span-3">
            <div class="vf-lbl">Notes</div>
            <div class="vf-val text-gray-600 whitespace-pre-line"><?= htmlspecialchars($wo['notes']) ?></div>
          </div>
          <?php endif; ?>

          <?php if ($wo['resolution_notes']): ?>
          <div class="col-span-2 md:col-span-3">
            <div class="vf-lbl">Resolution Notes</div>
            <div class="vf-val text-gray-600 whitespace-pre-line"><?= htmlspecialchars($wo['resolution_notes']) ?></div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Tabs card -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="tab-nav">
        <?php
        $tabs = [
          'checklist'   => 'Checklist',
          'parts'       => 'Parts Used (' . count($parts) . ')',
          'timelog'     => 'Time Log',
          'media'       => 'Media (' . count($media) . ')',
          'signoff'     => 'Sign-off',
          'communication' => 'Notes (' . count($notes) . ')',
          'assignments' => 'Assignment History (' . count($assignments) . ')',
        ];
        foreach ($tabs as $key => $label):
        ?>
        <button class="tab-btn <?= $active_tab === $key ? 'tab-on' : '' ?>"
                onclick="switchTab('<?= $key ?>')">
          <?= htmlspecialchars($label) ?>
        </button>
        <?php endforeach; ?>
      </div>

      <!-- Checklist tab -->
      <div id="tab-checklist" class="p-5 <?= $active_tab !== 'checklist' ? 'hidden' : '' ?>">
        <?php if ($checklist): ?>
          <?php
          $done_count  = count(array_filter($checklist, fn($i) => $i['is_done']));
          $total_items = count($checklist);
          $pct         = $total_items > 0 ? round($done_count / $total_items * 100) : 0;
          ?>
          <div class="flex items-center justify-between mb-4">
            <div>
              <span class="text-sm font-semibold text-gray-700"><?= htmlspecialchars($cl_name) ?></span>
              <span class="text-xs text-gray-400 ml-2"><?= $done_count ?>/<?= $total_items ?> items (<?= $pct ?>%)</span>
            </div>
          </div>
          <div class="cl-progress mb-4">
            <div class="cl-progress-fill" style="width:<?= $pct ?>%"></div>
          </div>
          <div>
            <?php foreach ($checklist as $item): ?>
            <div class="cl-item">
              <div class="cl-check <?= $item['is_done'] ? 'cl-done' : '' ?>">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
                </svg>
              </div>
              <div class="flex-1">
                <div class="cl-text">
                  <?= htmlspecialchars($item['item_text']) ?>
                  <?php if ($item['is_mandatory']): ?><span class="cl-mandatory">*</span><?php endif; ?>
                  <?php if ($item['requires_photo']): ?>
                    <svg class="inline w-3.5 h-3.5 text-gray-400 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"/>
                      <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z"/>
                    </svg>
                  <?php endif; ?>
                </div>
                <?php if ($item['is_done']): ?>
                  <div class="cl-meta">
                    Completed by <?= htmlspecialchars($item['completed_by_name'] ?? 'Unknown') ?>
                    · <?= $item['completed_at'] ? (new DateTime($item['completed_at']))->format('M j, g:ia') : '' ?>
                  </div>
                  <?php if ($item['completion_notes']): ?>
                    <div class="text-xs text-gray-500 mt-1"><?= htmlspecialchars($item['completion_notes']) ?></div>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="text-sm text-gray-400 italic">No checklist available for this work order.</p>
        <?php endif; ?>
      </div>

      <!-- Parts used tab -->
      <div id="tab-parts" class="p-5 <?= $active_tab !== 'parts' ? 'hidden' : '' ?>">
        <?php if ($parts): ?>
          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="border-b border-gray-200">
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Part</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Part #</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Qty</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Serial</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Warranty</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Used By</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($parts as $p): ?>
              <tr class="border-b border-gray-50">
                <td class="py-2 px-3 font-medium text-gray-700">
                  <?= htmlspecialchars($p['part_name']) ?>
                  <?php if (!empty($p['warranty_active'])): ?>
                    <span class="rma-chip" title="Asset under warranty (<?= htmlspecialchars($p['warranty_coverage'] ?? 'parts') ?>) — claim via vendor">RMA</span>
                  <?php endif; ?>
                </td>
                <td class="py-2 px-3 wo-tag"><?= htmlspecialchars($p['part_number']) ?></td>
                <td class="py-2 px-3 text-gray-600"><?= $p['quantity_used'] ?></td>
                <td class="py-2 px-3 text-gray-500 text-xs font-mono"><?= $p['serial_number'] ? htmlspecialchars($p['serial_number']) : '—' ?></td>
                <td class="py-2 px-3">
                  <?php if (!empty($p['warranty_active'])): ?>
                    <span class="wo-badge badge-type-diagnosis">Warranty</span>
                  <?php elseif ($p['is_warranty']): ?>
                    <span class="wo-badge badge-type-diagnosis">RMA</span>
                  <?php else: ?>
                    <span class="text-gray-300">—</span>
                  <?php endif; ?>
                </td>
                <td class="py-2 px-3 text-gray-600"><?= htmlspecialchars($p['used_by_name'] ?? '—') ?></td>
                <td class="py-2 px-3 text-gray-400 text-xs"><?= (new DateTime($p['used_at']))->format('M j, Y') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="text-sm text-gray-400 italic">No parts consumed on this work order.</p>
        <?php endif; ?>
      </div>

      <!-- Time log tab -->
      <div id="tab-timelog" class="p-5 <?= $active_tab !== 'timelog' ? 'hidden' : '' ?>">
        <?php if ($time_logs): ?>
          <div class="flex items-center gap-3 mb-4 p-3 bg-gray-50 rounded-lg">
            <svg class="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            <div>
              <span class="text-sm font-semibold text-gray-700">Total Logged Time:</span>
              <span class="text-sm font-bold text-olfu-green ml-1"><?= format_duration($total_time) ?></span>
            </div>
          </div>
          <div class="tl-wrap">
            <?php foreach ($time_logs as $tl): ?>
            <div class="tl-entry">
              <div class="tl-dot tl-<?= $tl['action'] ?>"></div>
              <div>
                <span class="tl-action text-<?= match($tl['action']) { 'start'=>'green-600', 'pause'=>'amber-600', 'resume'=>'blue-600', 'stop'=>'red-600', default=>'gray-600' } ?>">
                  <?= ucfirst($tl['action']) ?>
                </span>
                <?php if ($tl['labor_type']): ?>
                  <span class="wo-badge badge-type ml-2"><?= ucfirst(str_replace('_',' ',$tl['labor_type'])) ?></span>
                <?php endif; ?>
                <?php if (!empty($tl['elapsed_ms']) && (int)$tl['elapsed_ms'] > 0):
                  $ms = (int)$tl['elapsed_ms'];
                  $s  = (int)floor($ms / 1000);
                  $h  = str_pad((int)floor($s / 3600), 2, '0', STR_PAD_LEFT);
                  $m  = str_pad((int)floor(($s % 3600) / 60), 2, '0', STR_PAD_LEFT);
                  $sc = str_pad($s % 60, 2, '0', STR_PAD_LEFT);
                ?>
                  <span class="ml-2 font-mono text-xs font-bold text-olfu-green"><?= "$h:$m:$sc" ?></span>
                <?php endif; ?>
                <span class="tl-time ml-2"><?= (new DateTime($tl['logged_at']))->format('M j, g:ia') ?> · <?= htmlspecialchars($tl['technician_name'] ?? 'Unknown') ?></span>
                <?php if ($tl['notes']): ?>
                  <div class="tl-notes"><?= htmlspecialchars($tl['notes']) ?></div>
                <?php endif; ?>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="text-sm text-gray-400 italic">No time entries recorded yet. Time tracking is managed by technicians in Module 4.</p>
        <?php endif; ?>
      </div>

      <!-- Media tab -->
      <div id="tab-media" class="p-5 <?= $active_tab !== 'media' ? 'hidden' : '' ?>">
        <?php
          $renderMediaCard = function(array $m): void {
              $ft      = (string)($m['file_type'] ?? '');
              $isImage = str_starts_with($ft, 'image/')
                      || in_array(strtolower($ft), ['jpg','jpeg','png','gif','webp'], true);
              $typeSlug = htmlspecialchars(str_replace('_', '-', $m['media_type']));
              $typeLbl  = ucfirst(str_replace(['photo_', '_'], ['', ' '], $m['media_type']));
              $filePath = htmlspecialchars($m['file_path']);
              $filename = basename(parse_url($m['file_path'], PHP_URL_PATH));
              $ext      = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
              $caption  = $m['caption'] ?? '';
              $sizeKb   = (int)($m['file_size_kb'] ?? 0);
              $sizeStr  = $sizeKb > 1024 ? round($sizeKb / 1024, 1) . ' MB' : ($sizeKb > 0 ? $sizeKb . ' KB' : '');
              // File icon colour by extension
              $iconColor = match(true) {
                  $ext === 'pdf'                              => '#dc2626',
                  in_array($ext, ['zip','tar','gz','bz2','7z','rar'], true) => '#d97706',
                  in_array($ext, ['json','xml','yaml','yml','conf','config','ini','toml'], true) => '#059669',
                  default                                    => '#6b7280',
              };
        ?>
          <div class="media-card<?= !$isImage ? ' media-card-file' : '' ?>">
            <?php if ($isImage): ?>
              <a href="<?= $filePath ?>" target="_blank" class="block relative" style="display:block;position:relative;">
                <img src="<?= $filePath ?>" alt="<?= htmlspecialchars($caption) ?>" class="media-thumb" />
                <div class="media-thumb-overlay">
                  <svg class="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                  </svg>
                </div>
              </a>
              <div class="media-info">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;">
                  <span class="media-type media-<?= $typeSlug ?>"><?= $typeLbl ?></span>
                  <a href="<?= $filePath ?>" download="<?= htmlspecialchars($filename) ?>" class="media-dl-btn" title="Download">
                    <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                    </svg>
                  </a>
                </div>
                <?php if ($caption): ?>
                  <p class="text-xs text-gray-600 mt-1"><?= htmlspecialchars($caption) ?></p>
                <?php endif; ?>
                <p class="text-xs text-gray-400 mt-1"><?= htmlspecialchars($m['uploaded_by_name'] ?? '—') ?> · <?= (new DateTime($m['uploaded_at']))->format('M j') ?></p>
              </div>
            <?php else: ?>
              <div class="media-file-row">
                <div class="media-file-icon-wrap">
                  <svg class="w-6 h-6" style="color:<?= $iconColor ?>" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/>
                  </svg>
                  <?php if ($ext): ?>
                    <span class="media-file-ext"><?= strtoupper($ext) ?></span>
                  <?php endif; ?>
                </div>
                <div class="media-file-details">
                  <p class="media-file-name"><?= htmlspecialchars($caption ?: $filename) ?></p>
                  <?php if ($caption && $caption !== $filename): ?>
                    <p class="text-xs text-gray-400 font-mono" style="margin-top:1px;"><?= htmlspecialchars($filename) ?></p>
                  <?php endif; ?>
                  <p class="media-file-meta">
                    <?= htmlspecialchars($m['uploaded_by_name'] ?? '—') ?>
                    · <?= (new DateTime($m['uploaded_at']))->format('M j, Y') ?>
                    <?php if ($sizeStr): ?> · <?= $sizeStr ?><?php endif; ?>
                  </p>
                </div>
                <a href="<?= $filePath ?>" download="<?= htmlspecialchars($filename) ?>" class="media-dl-btn-primary">
                  <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                  </svg>
                  Download
                </a>
              </div>
            <?php endif; ?>
          </div>
        <?php }; ?>

        <?php if (!$media): ?>
          <p class="text-sm text-gray-400 italic">No media captured yet. Photos and evidence are uploaded by technicians during work order execution.</p>
        <?php else: ?>
          <div class="space-y-4">

            <!-- Before section -->
            <div class="wo-media-section">
              <div class="wo-media-section-header">
                <div class="wo-media-section-title">
                  <svg class="wo-media-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.776 48.776 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"/><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z"/>
                  </svg>
                  Before
                </div>
                <span class="wo-media-count">(<?= count($before_media) ?> files)</span>
              </div>
              <div class="wo-media-grid">
                <?php if ($before_media): ?>
                  <?php foreach ($before_media as $m): $renderMediaCard($m); endforeach; ?>
                <?php else: ?>
                  <p class="text-sm text-gray-400 italic col-span-3">No before photos captured.</p>
                <?php endif; ?>
              </div>
            </div>

            <!-- After section -->
            <div class="wo-media-section">
              <div class="wo-media-section-header">
                <div class="wo-media-section-title">
                  <svg class="wo-media-icon wo-media-icon-after" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.776 48.776 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"/><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z"/>
                  </svg>
                  After
                </div>
                <span class="wo-media-count">(<?= count($after_media) ?> files)</span>
              </div>
              <div class="wo-media-grid">
                <?php if ($after_media): ?>
                  <?php foreach ($after_media as $m): $renderMediaCard($m); endforeach; ?>
                <?php else: ?>
                  <p class="text-sm text-gray-400 italic col-span-3">No after photos captured.</p>
                <?php endif; ?>
              </div>
            </div>

            <!-- Configuration Backups & Logs section -->
            <div class="wo-media-section">
              <div class="wo-media-section-header">
                <div class="wo-media-section-title">
                  <svg class="wo-media-icon wo-media-icon-config" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                  </svg>
                  Configuration Backups &amp; Logs
                </div>
                <span class="wo-media-count">(<?= count($config_media) ?> files)</span>
              </div>
              <div class="wo-media-grid-config">
                <?php if ($config_media): ?>
                  <?php foreach ($config_media as $m): $renderMediaCard($m); endforeach; ?>
                <?php else: ?>
                  <p class="text-sm text-gray-400 italic">No configuration files uploaded.</p>
                <?php endif; ?>
              </div>
            </div>

          </div>
        <?php endif; ?>
      </div>

      <!-- Sign-off tab -->
      <div id="tab-signoff" class="p-5 <?= $active_tab !== 'signoff' ? 'hidden' : '' ?>">
        <?php if ($signoff): ?>
          <div class="signoff-card">
            <div class="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div class="vf-lbl">Signed By</div>
                <div class="vf-val"><?= htmlspecialchars($signoff['signer_name']) ?></div>
              </div>
              <div>
                <div class="vf-lbl">Signed At</div>
                <div class="vf-val"><?= (new DateTime($signoff['signed_at']))->format('M j, Y g:ia') ?></div>
              </div>
            </div>
            <?php if (!empty($signoff['signature_path']) && $signoff['signature_path'] !== 'data:inline'): ?>
            <div class="mb-4">
              <div class="vf-lbl">Signature</div>
              <img src="<?= htmlspecialchars($signoff['signature_path']) ?>"
                   alt="Customer signature"
                   style="max-height:120px; border:1px solid #e5e7eb; border-radius:4px; background:#fff; padding:4px;" />
            </div>
            <?php endif; ?>
            <?php if ($signoff['satisfaction'] !== null): ?>
            <div class="mb-3">
              <div class="vf-lbl">Satisfaction</div>
              <div class="flex gap-1 mt-1">
                <?php for ($s = 1; $s <= 5; $s++): ?>
                  <span class="star <?= $s <= $signoff['satisfaction'] ? 'star-on' : '' ?>">★</span>
                <?php endfor; ?>
              </div>
            </div>
            <?php endif; ?>
            <?php if ($signoff['feedback']): ?>
            <div>
              <div class="vf-lbl">Feedback</div>
              <div class="text-sm text-gray-600 mt-1 whitespace-pre-line"><?= htmlspecialchars($signoff['feedback']) ?></div>
            </div>
            <?php endif; ?>
          </div>
        <?php else: ?>
          <p class="text-sm text-gray-400 italic">Awaiting requester sign-off. This will be captured by the technician at completion.</p>
        <?php endif; ?>
      </div>
 
      <!-- Communication / Notes tab -->
      <div id="tab-communication" class="p-5 <?= $active_tab !== 'communication' ? 'hidden' : '' ?>">
        <div style="display:grid;grid-template-columns:1fr;gap:16px;align-items:start;">
          <!-- Saved notes panel -->
          <div class="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
            <div class="px-4 py-3 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <svg class="w-3.5 h-3.5 text-olfu-green" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                <span class="text-sm font-bold text-gray-900">Saved Notes</span>
              </div>
              <span id="notesCount" class="text-xs text-gray-400">0 notes</span>
            </div>
            <div class="px-4 py-2 border-b border-gray-50 flex items-center gap-2 flex-wrap">
              <span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mr-1">Filter</span>
              <button type="button" class="note-filter-chip note-filter-chip--on" data-filter="all" onclick="filterNotes('all', this)">All</button>
              <button type="button" class="note-filter-chip" data-filter="general" onclick="filterNotes('general', this)">General</button>
              <button type="button" class="note-filter-chip" data-filter="progress" onclick="filterNotes('progress', this)">Progress</button>
              <button type="button" class="note-filter-chip" data-filter="issue" onclick="filterNotes('issue', this)">Issue</button>
              <button type="button" class="note-filter-chip" data-filter="follow_up" onclick="filterNotes('follow_up', this)">Follow-up</button>
            </div>
            <div class="p-4 min-h-[200px]" id="notesListContainer">
              <div id="notesList"></div>
              <div id="notesEmptyState" class="py-10 text-center">
                <div class="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <svg class="w-5 h-5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931z"/>
                  </svg>
                </div>
                <p class="text-sm text-gray-400 italic">No notes captured for this work order.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Assignment history tab -->
      <div id="tab-assignments" class="p-5 <?= $active_tab !== 'assignments' ? 'hidden' : '' ?>">
        <?php if ($assignments): ?>
          <table class="w-full border-collapse text-sm">
            <thead>
              <tr class="border-b border-gray-200">
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">From</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">To</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Assigned By</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Reason</th>
                <th class="py-2 px-3 text-left text-xs font-bold uppercase tracking-wider text-gray-400">Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($assignments as $a): ?>
              <tr class="border-b border-gray-50">
                <td class="py-2 px-3 text-gray-600"><?= $a['from_name'] ? htmlspecialchars($a['from_name']) : '<span class="text-gray-300 italic">—</span>' ?></td>
                <td class="py-2 px-3 font-medium text-gray-700"><?= htmlspecialchars($a['to_name'] ?? '—') ?></td>
                <td class="py-2 px-3 text-gray-600"><?= htmlspecialchars($a['by_name'] ?? '—') ?></td>
                <td class="py-2 px-3 text-gray-500 text-xs"><?= $a['reason'] ? htmlspecialchars($a['reason']) : '—' ?></td>
                <td class="py-2 px-3 text-gray-400 text-xs"><?= (new DateTime($a['assigned_at']))->format('M j, Y g:ia') ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php else: ?>
          <p class="text-sm text-gray-400 italic">No assignment changes recorded yet.</p>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- /left column -->

  <!-- RIGHT PANEL -->
  <div class="flex flex-col gap-3">

    <!-- Quick info -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="rp-hdr">WO Quick Info</div>
      <div class="px-4 py-2">
        <div class="rp-row">
          <span class="rp-lbl">WO Number</span>
          <span class="rp-val wo-tag"><?= htmlspecialchars($wo['wo_number']) ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Status</span>
          <span><?= wo_status_badge($wo['status']) ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Type</span>
          <span><?= wo_type_badge($wo['wo_type']) ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Assigned To</span>
          <span class="rp-val"><?= $wo['technician_name'] ? htmlspecialchars($wo['technician_name']) : '<span class="text-gray-300 italic text-xs">Unassigned</span>' ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Ticket</span>
          <span class="rp-val <?= $wo['ticket_number'] ? 'wo-tag' : 'text-gray-300 italic text-xs' ?>"><?= $wo['ticket_number'] ? htmlspecialchars($wo['ticket_number']) : 'None' ?></span>
        </div>
        <?php if ($wo['asset_tag']): ?>
        <div class="rp-row">
          <span class="rp-lbl">Asset</span>
          <span class="rp-val wo-tag"><?= htmlspecialchars($wo['asset_tag']) ?></span>
        </div>
        <?php endif; ?>
        <div class="rp-row">
          <span class="rp-lbl">RMA</span>
          <span class="rp-val"><?= $wo['is_rma'] ? 'Yes' : 'No' ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Checklist</span>
          <span class="rp-val">
            <?php if ($checklist):
              $done_c = count(array_filter($checklist, fn($i) => $i['is_done']));
            ?>
              <?= $done_c ?>/<?= count($checklist) ?>
            <?php else: ?>
              <span class="text-gray-300 text-xs">—</span>
            <?php endif; ?>
          </span>
        </div>
      </div>
    </div>

    <!-- Schedule panel -->
    <?php if ($wo['scheduled_start'] || $wo['scheduled_end']): ?>
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="rp-hdr">Schedule</div>
      <div class="px-4 py-2">
        <?php if ($wo['scheduled_start']): ?>
        <div class="rp-row">
          <span class="rp-lbl">Start</span>
          <span class="rp-val text-xs"><?= (new DateTime($wo['scheduled_start']))->format('M j, g:ia') ?></span>
        </div>
        <?php endif; ?>
        <?php if ($wo['scheduled_end']): ?>
        <div class="rp-row">
          <span class="rp-lbl">End</span>
          <span class="rp-val text-xs <?= $is_overdue ? 'text-red-600' : '' ?>"><?= (new DateTime($wo['scheduled_end']))->format('M j, g:ia') ?></span>
        </div>
        <?php endif; ?>
        <?php if ($total_time > 0): ?>
        <div class="rp-row">
          <span class="rp-lbl">Logged Time</span>
          <span class="rp-val text-xs"><?= format_duration($total_time) ?></span>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Record info -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="rp-hdr">Record Info</div>
      <div class="px-4 py-2">
        <div class="rp-row">
          <span class="rp-lbl">Created By</span>
          <span class="rp-val text-xs"><?= $wo['created_by_name'] ? htmlspecialchars($wo['created_by_name']) : '—' ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Created</span>
          <span class="rp-val text-xs"><?= (new DateTime($wo['created_at']))->format('M j, Y') ?></span>
        </div>
        <div class="rp-row">
          <span class="rp-lbl">Last Updated</span>
          <span class="rp-val text-xs"><?= wo_time_ago($wo['updated_at']) ?></span>
        </div>
      </div>
    </div>

    <!-- Quick reassign -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="rp-hdr">Quick Reassign</div>
      <div class="px-4 py-3">
        <select id="reassign-tech" class="fsel w-full mb-2">
          <option value="">— Select technician —</option>
          <?php foreach ($technicians as $t): ?>
            <option value="<?= $t['user_id'] ?>" <?= $wo['assigned_to'] == $t['user_id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($t['full_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <input type="text" id="reassign-reason" class="fin text-sm mb-2" placeholder="Reason for reassignment…" />
        <button id="reassign-btn" onclick="doReassign()"
                class="w-full bg-olfu-green text-white text-sm font-semibold py-2 rounded-lg hover:bg-olfu-green-md transition-colors disabled:opacity-40 disabled:cursor-not-allowed" disabled>
          Reassign
        </button>
        <button id="auto-assign-btn" type="button" onclick="doAutoAssign()"
                class="w-full mt-2 bg-white border border-emerald-200 text-emerald-700 text-sm font-semibold py-2 rounded-lg hover:bg-emerald-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
          ✨ Auto-assign by skill + location
        </button>
        <p id="reassign-msg" class="text-xs mt-2 hidden"></p>
      </div>
    </div>

    <!-- KB Articles -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div class="rp-hdr flex items-center gap-2">
        <svg class="w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
        </svg>
        Knowledge Base
      </div>
      <div class="px-4 py-2 text-sm divide-y divide-gray-100">
        <?php if ($kb_articles): ?>
          <?php foreach ($kb_articles as $kb): ?>
          <details class="group py-2">
            <summary class="flex items-center justify-between cursor-pointer font-medium text-gray-700 hover:text-olfu-green">
              <span><?= htmlspecialchars($kb['title']) ?></span>
              <span class="transition group-open:rotate-180">
                <svg fill="none" height="16" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="16"><polyline points="6 9 12 15 18 9"/></svg>
              </span>
            </summary>
            <div class="text-gray-600 mt-2 text-xs whitespace-pre-wrap leading-relaxed"><?= htmlspecialchars($kb['content']) ?></div>
          </details>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="py-3 text-xs text-gray-400 italic">No knowledge aids found for this work order.</p>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- /right panel -->

</div><!-- /grid -->

<script>
function switchTab(key) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('tab-on'));
  document.querySelectorAll('[id^="tab-"]').forEach(p => p.classList.add('hidden'));
  event.currentTarget.classList.add('tab-on');
  const panel = document.getElementById('tab-' + key);
  if (panel) panel.classList.remove('hidden');
}

// Quick reassign
const reassignTech   = document.getElementById('reassign-tech');
const reassignReason = document.getElementById('reassign-reason');
const reassignBtn    = document.getElementById('reassign-btn');
const reassignMsg    = document.getElementById('reassign-msg');

reassignTech.addEventListener('change', () => {
  reassignBtn.disabled = !reassignTech.value;
});

function doReassign() {
  const tech   = reassignTech.value;
  const reason = reassignReason.value.trim();
  if (!tech) return;

  reassignBtn.disabled    = true;
  reassignBtn.textContent = 'Saving…';
  reassignMsg.classList.add('hidden');

  const fd = new FormData();
  fd.append('wo_id',       <?= $id ?>);
  fd.append('assigned_to', tech);
  fd.append('reason',      reason);

  fetch('assign.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      reassignBtn.textContent = 'Reassign';
      if (data.success) {
        reassignMsg.className = 'text-xs mt-2 text-green-600';
        reassignMsg.textContent = 'Technician reassigned successfully.';
        reassignMsg.classList.remove('hidden');
        setTimeout(() => location.reload(), 1200);
      } else {
        reassignMsg.className = 'text-xs mt-2 text-red-600';
        reassignMsg.textContent = data.message || 'Reassignment failed.';
        reassignMsg.classList.remove('hidden');
        reassignBtn.disabled = false;
      }
    })
    .catch(() => {
      reassignBtn.textContent = 'Reassign';
      reassignBtn.disabled = false;
      reassignMsg.className = 'text-xs mt-2 text-red-600';
      reassignMsg.textContent = 'Network error. Please try again.';
      reassignMsg.classList.remove('hidden');
    });
}

// Auto-assign based on skill + location
function doAutoAssign() {
  const btn = document.getElementById('auto-assign-btn');
  btn.disabled = true;
  btn.textContent = 'Finding best match…';
  reassignMsg.classList.add('hidden');

  const fd = new FormData();
  fd.append('wo_id', <?= (int)$wo['wo_id'] ?>);

  fetch('auto_assign.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      btn.textContent = '✨ Auto-assign by skill + location';
      btn.disabled = false;
      if (data.success) {
        reassignMsg.className = 'text-xs mt-2 text-green-600';
        reassignMsg.textContent = data.message || 'Auto-assigned successfully.';
        reassignMsg.classList.remove('hidden');
        setTimeout(() => window.location.reload(), 800);
      } else {
        reassignMsg.className = 'text-xs mt-2 text-red-600';
        reassignMsg.textContent = data.message || 'Auto-assignment failed.';
        reassignMsg.classList.remove('hidden');
      }
    })
    .catch(() => {
      btn.textContent = '✨ Auto-assign by skill + location';
      btn.disabled = false;
      reassignMsg.className = 'text-xs mt-2 text-red-600';
      reassignMsg.textContent = 'Network error. Please try again.';
      reassignMsg.classList.remove('hidden');
    });
}

// ── Notes Module Logic ────────────────────────────────────────
let activeNoteTag = 'general';
let activeNoteFilter = 'all';
let allNotes = <?= json_encode($notes) ?>;

function filterNotes(filter, btn) {
    activeNoteFilter = filter;
    document.querySelectorAll('.note-filter-chip').forEach(b => b.classList.remove('note-filter-chip--on'));
    btn.classList.add('note-filter-chip--on');
    renderNotes();
}

function renderNotes() {
    const list = document.getElementById('notesList');
    const empty = document.getElementById('notesEmptyState');
    const count = document.getElementById('notesCount');
    
    const filtered = activeNoteFilter === 'all' 
        ? allNotes 
        : allNotes.filter(n => (n.note_type || 'general') === activeNoteFilter);
    
    count.textContent = allNotes.length + ' note' + (allNotes.length !== 1 ? 's' : '');
    const tabLabel = document.getElementById('tab-btn-communication');
    if (tabLabel) tabLabel.textContent = `Notes (${allNotes.length})`;
    
    if (filtered.length === 0) {
        list.innerHTML = '';
        empty.style.display = 'block';
    } else {
        empty.style.display = 'none';
        list.innerHTML = filtered.map(n => {
            const tagLabels = { general: 'General', progress: 'Progress', issue: 'Issue', follow_up: 'Follow-up' };
            const type = n.note_type || 'general';
            
            // Try to extract title if formatted as [Title] Text
            let title = '';
            let text = n.note_text || '';
            const match = text.match(/^\[(.*?)\]\s*(.*)$/);
            if (match) {
                title = match[1];
                text = match[2];
            }

            return `
                <div class="note-card">
                    <span class="note-card__tag note-card__tag--${type}">${tagLabels[type] || type}</span>
                    <div class="note-card__title">${title ? escapeHtml(title) : '<em>Untitled</em>'}</div>
                    <div class="note-card__text">${escapeHtml(text)}</div>
                    <div class="note-card__meta">${escapeHtml(n.added_by_name || 'System')} · ${new Date(n.added_at).toLocaleString()}</div>
                </div>
            `;
        }).join('');
    }
}


function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderNotes();
});
</script>

<style>
.note-filter-chip {
    padding: 4px 12px; border-radius: 999px; font-size: 12px; font-weight: 500;
    border: 1.5px solid #e5e7eb; background: #fff; color: #6b7280; cursor: pointer;
    transition: all .12s;
}
.note-filter-chip:hover { border-color: #86efac; color: #15803d; background: #f0fdf4; }
.note-filter-chip--on { background: #15803d !important; color: #fff !important; border-color: #15803d !important; }

.note-card { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; margin-bottom: 8px; }
.note-card__tag { display: inline-flex; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 999px; margin-bottom: 6px; text-transform: capitalize; }
.note-card__tag--general { background: #f3f4f6; color: #6b7280; }
.note-card__tag--progress { background: #eff6ff; color: #1d4ed8; }
.note-card__tag--issue { background: #fef2f2; color: #b91c1c; }
.note-card__tag--follow_up { background: #fdf4ff; color: #7e22ce; }
.note-card__title { font-size: 13px; font-weight: 700; color: #1f2937; margin-bottom: 2px; }
.note-card__text { font-size: 12.5px; color: #4b5563; line-height: 1.5; }
.note-card__meta { font-size: 10.5px; color: #9ca3af; margin-top: 6px; }
</style>
